
import { useSelector } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import './App.css';
import Routes from './routes';



const Routing = ({ LoggedIn }) => {
  if (LoggedIn) {
    return <Routes isLoggedIn={true} />
  } else {
    return <Routes isLoggedIn={false} />
  }
}
function App() {
  const {token} = useSelector(state => state.auth)
  console.log(token, "hhhhhhhhhhhhhhhhhhhhhh")
  
  return (
    <div className="App">
      <Router>
        <Routing LoggedIn={token} />

      </Router>
    </div>
  );
}

export default App;
