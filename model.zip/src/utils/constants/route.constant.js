export const ROUTE_NAME = {
    BASE:'/',
    DASHBOARD:'/dashboard',
    LOGIN:"/login",
    // CHANGE_PASSWORD : "/change-password/:token",
    // SET_NEW_PASSWORD:"/update-password",
    //=============== Leads Related Routes=========//
  };
  
  export const ROUTE_DEFINATION = {
    BASE: ROUTE_NAME.BASE,
   // CHANGE_PASSWORD : ROUTE_NAME.CHANGE_PASSWORD,
    DASHBOARD: ROUTE_NAME.DASHBOARD,
    
  };
  