import { Outlet } from "react-router-dom";

//=======================||Login Layout||============//
const LoginLayout = ()=>(
<>      
<Outlet/>
</>
)

export default  LoginLayout