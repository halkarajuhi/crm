import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  loading: false,
  userInfo: {}, // for user object
  userToken: null, // for storing the JWT
  error: null,
  success: false, // for monitoring the registration process.
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
		removeToken: (state, action) => {
			state.token = null;
			state.user = null;
		},
		setToken: (state, action) => {
			state.token = "fsdfsdfsdfsdfsdklfnjmskldfmnsdklfmnsdklsklgjmn";
			state.user = {name:"GO Mechanic"};
		},
	},
  extraReducers: {},
})
export const {removeToken,setToken } = authSlice.actions
export default authSlice.reducer