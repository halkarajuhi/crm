export const THUNK_STATUS = {
    LOADING: "loading",
    SUCCESS: "success",
    FAILED: "failed",
  };
  export const replaceUrl = (url, data) => {
    var regex = new RegExp(":(" + Object.keys(data).join("|") + ")", "g");
    return url?.replace(regex, (m, $1) => data[$1] || m);
  };

  export const METHODS = {
    GET: "GET",
    POST: "POST",
    PUT: "PUT",
    DELETE: "DELETE",
    PATCH: "PATCH",
  };