import React from 'react'
import  Loadable from 'react-loadable';
import { Navigate } from 'react-router';
import LoginLayout from '../layout/LoginLayout';
import { ROUTE_DEFINATION } from '../utils/constants/route.constant';



const Login = Loadable({loader:()=> import("../components/pages/login/index"),
loading: ()=> <h1>Loading....</h1>,
 })

const  PublicRoutes ={
    element:<LoginLayout/>,
    children:[
    {
        path:ROUTE_DEFINATION.BASE,
        title:ROUTE_DEFINATION.BASE,
        element:<Login/>
    },
    {
        path:"*",
        element:<Navigate to={ROUTE_DEFINATION.BASE}/>
    }
    ]
}


export default PublicRoutes
 