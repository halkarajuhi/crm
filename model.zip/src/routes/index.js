import { useRoutes } from "react-router";
import { useEffect,useState } from "react";
import privateRoutes from './privateRoutes';
import publicRoutes from './publicRoutes';

export default  function Routes ({isLoggedIn}){
    const [aciveRoutes, setActiveRoutes] = useState([]);
   console.log(isLoggedIn,"..................................")
    useEffect(()=>{
        if(isLoggedIn){
            setActiveRoutes([privateRoutes]);
        }
        else{
            setActiveRoutes([publicRoutes]);
        }
    }, [isLoggedIn]);
    return useRoutes(aciveRoutes);
}