import Loadable from 'react-loadable';
import { Navigate } from 'react-router';
import Loading from '../components/pages/loadnig';
import MainLayout from '../layout/MainLayout';
import { ROUTE_DEFINATION } from '../utils/constants/route.constant';
const Dashboard = Loadable({
    loader:()=> import('../components/pages/dashboard'),
loading:() => <Loading/>,
});

const privateRoutes={
        element:<MainLayout/>,
children:[
    {
        path:ROUTE_DEFINATION.DASHBOARD,
        title:ROUTE_DEFINATION.DASHBOARD,
        element:<Dashboard/>
        
    },
    
  
    {
        path:"*",
        title:"",
        element:<Navigate to={ROUTE_DEFINATION.DASHBOARD}/>
    }
]
}
export default privateRoutes;