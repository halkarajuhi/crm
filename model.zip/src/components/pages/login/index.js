import { useTheme } from '@emotion/react'
import { Typography } from '@mui/material'
import React from 'react'
import { useDispatch } from 'react-redux';
import { removeToken, setToken } from '../../../redux/slices/auth.slice';

export default function Login() {
  const theme = useTheme();
  const dispatch =useDispatch()
  console.log(theme)
  const handleLogin =()=>{
dispatch(setToken())

  }
 
  return (
    <div>
      <Typography color="primary" variant='h1'> Login page</Typography>
      <button onClick={()=>handleLogin()}>
        Login
      </button>
     
      </div>
  )
}
