import React from 'react'
import { useDispatch } from 'react-redux'
import { removeToken } from '../../../redux/slices/auth.slice'

export default function Dashboard() {
  const dispatch =useDispatch()
  const handleLogout =()=>{
    dispatch(removeToken())
      }
  return (
    <div>Dashboard
       <button onClick={()=>handleLogout()}>
       Logout
      </button>
    </div>
    
  )
}
