import React from 'react'

const Loading = () => {
  return (
    <>
      <h1>laoding</h1> 
    </>
  )
}

export default Loading
